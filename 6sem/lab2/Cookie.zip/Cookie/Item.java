
public interface Item {
	public String getItemName();
	public double getPrice();
	public void setPrice(double price);
	public String getDepartment();
}
