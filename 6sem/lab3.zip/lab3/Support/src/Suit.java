
public enum Suit {
	CLUBS,
	DIAMONDS,
	HEARTS, 
	SPADES,
	CHANDELER;
	
    public void Hello() {
        // Реализация метода
        System.out.println("Привет!");
    }
}