
public interface Item {

	String getItemName();
	double getPrice();
	void setPrice(double price);
	String getDepartment();
}
