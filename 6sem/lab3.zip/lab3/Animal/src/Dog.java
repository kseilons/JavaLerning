public class Dog extends Animal {
	int x;
	public void makeNoise() {
		System.out.println("Bark");
	}//end method makeNoise
}//end class Dog