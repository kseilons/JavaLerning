
public final class CompanyColor {

	private final int r = 238;
	private final int g = 130;
	private final int b = 238;
	
	public int getR() {
		return r;
	}
	
	public int getG() {
		return g;
	}
	
	
	public int getB() {
		return b;
	}
	
}
